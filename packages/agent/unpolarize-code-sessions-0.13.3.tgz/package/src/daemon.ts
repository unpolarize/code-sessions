import { existsSync, mkdirSync, rmSync } from 'node:fs';
import { createServer, type Server, type Socket } from 'node:net';
import { join } from 'node:path';
import { monitorEventLoopDelay } from 'node:perf_hooks';
import type { SessionEvent } from '@unpolarize/code-sessions-schema';
import { CaptureEngine } from './capture';
import type { CodeSessionsConfig } from './config';
import { isSessionEndEvent, parseHookEvent, type HookAck, type HookEvent } from './ipc';
import { handleRpc, parseLine, type RpcContext } from './rpc';
import { initTrace, startFileSink, startSpan } from './hostTrace';
import { SessionService } from './sessionService';
import { StateStore } from './state';
import { GitStore } from './store/git';
import { readEntries } from './store/scan';
import { SourceWatcher, type ScanResult } from './watcher';
import { TaskRegistry } from './tasks';
import { OtelReceiver } from './telemetry/receiver';

export type SessionEndHook = (sessionId: string, sessionDir: string) => void | Promise<void>;

export interface DaemonDeps {
  capture?: CaptureEngine;
  state?: StateStore;
  git?: GitStore;
  /** invoked on Stop/SubagentStop — the insights labeler hooks in here */
  onSessionEnd?: SessionEndHook;
  /** invoked on EVERY hook arrival (fire-and-forget) — real-time OTel log emission */
  onHookEvent?: (evt: HookEvent) => void | Promise<void>;
  /** poll-based capture for hookless agents (codex/grok); auto-created from config when omitted */
  watcher?: SourceWatcher;
  /** OTLP-trigger receiver (agent telemetry → capture); auto-created from config when omitted */
  receiver?: OtelReceiver;
}

export interface DaemonStatus {
  running: boolean;
  socketPath: string;
  storeDir: string;
  events: number;
  turns: number;
  commits: number;
  sessions: string[];
}

/** Find a Claude transcript file by session id under the projects dir (bounded scan). */
export function findTranscript(projectsDir: string, sessionId: string, maxDepth = 3): string | undefined {
  const target = `${sessionId}.jsonl`;
  const walk = (dir: string, depth: number): string | undefined => {
    if (depth > maxDepth || !existsSync(dir)) return undefined;
    const entries = readEntries(dir);
    for (const e of entries) {
      if (e.isFile() && String(e.name) === target) return join(dir, String(e.name));
    }
    for (const e of entries) {
      if (e.isDirectory()) {
        const found = walk(join(dir, String(e.name)), depth + 1);
        if (found) return found;
      }
    }
    return undefined;
  };
  return walk(projectsDir, 0);
}

/**
 * The headless capture daemon. Listens on a unix socket for hook events,
 * captures appended turns immediately, and batches git commits (flush on
 * session-end, on a turn threshold, or after an interval).
 */
export class Daemon {
  private server?: Server;
  private readonly capture: CaptureEngine;
  private readonly state: StateStore;
  private readonly git?: GitStore;
  private readonly onSessionEnd?: SessionEndHook;
  private readonly onHookEvent?: (evt: HookEvent) => void | Promise<void>;
  private watcher?: SourceWatcher;
  private receiver?: OtelReceiver;
  private readonly triggerTimers = new Map<string, ReturnType<typeof setTimeout>>();
  /** Serial background queue for hook processing, so the socket ack is never blocked. */
  private workQueue: Promise<unknown> = Promise.resolve();

  private dirty = false;
  private pendingTurns = 0;
  private commitTimer?: ReturnType<typeof setTimeout>;
  private hygieneTimer?: ReturnType<typeof setInterval>;
  private readonly tasks = new TaskRegistry();
  private hygieneKick?: ReturnType<typeof setTimeout>;
  private running = false;
  private readonly stats = { events: 0, turns: 0, commits: 0 };
  private readonly sessions = new Set<string>();
  readonly sessionService: SessionService;
  private readonly lagHist = monitorEventLoopDelay({ resolution: 20 });
  private daemonVersion = '0.13.3';
  /** Live `session.event` subscribers. Missing `id` means all sessions. */
  private readonly subscribers = new Map<Socket, { id?: string }>();

  constructor(
    private readonly cfg: CodeSessionsConfig,
    deps: DaemonDeps = {},
  ) {
    this.state = deps.state ?? new StateStore(cfg.statePath);
    this.capture = deps.capture ?? new CaptureEngine(cfg, this.state);
    if (cfg.git.autoCommit) {
      this.git =
        deps.git ??
        new GitStore(cfg.storeDir, {
          ...(cfg.git.remote ? { remote: cfg.git.remote } : {}),
          autoPush: cfg.git.autoPush,
        });
    }
    if (deps.onSessionEnd) this.onSessionEnd = deps.onSessionEnd;
    if (deps.onHookEvent) this.onHookEvent = deps.onHookEvent;
    if (deps.watcher) this.watcher = deps.watcher;
    if (deps.receiver) this.receiver = deps.receiver;
    this.sessionService = new SessionService(cfg);
    this.sessionService.onEvent((id, rec) => this.fanoutSessionEvent(id, rec));
  }

  private fanoutSessionEvent(id: string, rec: SessionEvent): void {
    if (this.subscribers.size === 0) return;
    const line = `${JSON.stringify({
      jsonrpc: '2.0',
      method: 'session.event',
      params: { id, seq: rec.seq, ts: rec.ts, event: rec.event },
    })}\n`;
    for (const [sock, filter] of this.subscribers) {
      if (filter.id && filter.id !== id) continue;
      if (sock.destroyed) {
        this.subscribers.delete(sock);
        continue;
      }
      try {
        sock.write(line);
      } catch {
        this.subscribers.delete(sock);
      }
    }
  }

  async start(): Promise<void> {
    initTrace('cs', this.daemonVersion);
    startFileSink();
    const span = startSpan('cs.start');
    mkdirSync(this.cfg.storeDir, { recursive: true });
    mkdirSync(this.cfg.runtimeDir, { recursive: true });
    this.git?.init();
    if (existsSync(this.cfg.socketPath)) rmSync(this.cfg.socketPath);
    await new Promise<void>((resolve, reject) => {
      const server = createServer((sock) => this.onConnection(sock));
      server.on('error', reject);
      server.listen(this.cfg.socketPath, () => {
        this.running = true;
        resolve();
      });
      this.server = server;
    });
    span.mark('listen');

    // Poll-based capture for hookless agents (codex/grok). Auto-create from config
    // unless one was injected. Runs an immediate scan, then on its own interval.
    if (!this.watcher) {
      const w = new SourceWatcher(this.cfg, this.state);
      if (w.enabled) this.watcher = w;
    }
    this.watcher?.start(
      (r) => this.onWatcherImported(r),
      (r) => {
        this.tasks.watcherScan(this.cfg.capture.watch.intervalMs);
        if (r.imported > 0) {
          this.tasks.record('watcher.scan', {
            detail: `imported ${r.imported} (grok ${r.perAgent.grok.imported} · codex ${r.perAgent.codex.imported}) · ${r.turns} turns`,
          });
        }
      },
    );
    span.mark('watcher');

    // OTLP-trigger receiver: an agent's own telemetry export drives capture.
    // Auto-create from config unless injected; resilient — a port clash logs and
    // leaves the daemon running on hooks/watch alone.
    if (!this.receiver && this.cfg.capture.otelTrigger.enabled) {
      this.receiver = new OtelReceiver(this.cfg.capture.otelTrigger, {
        onTrigger: (sessionId) => this.handleTrigger(sessionId),
      });
    }
    if (this.receiver) {
      try {
        await this.receiver.start();
      } catch {
        this.receiver = undefined; // port unavailable — degrade gracefully
      }
    }

    // Label/reindex (or a crashed flush) can leave session.json dirty without
    // flipping this.dirty. Pick those up shortly after start and every 5 min.
    this.hygieneKick = setTimeout(() => this.flushLeftover('hygiene leftover'), 3000);
    this.hygieneKick.unref?.();
    this.hygieneTimer = setInterval(() => this.flushLeftover('hygiene leftover'), 5 * 60 * 1000);
    this.hygieneTimer.unref?.();
    this.lagHist.enable();
    span.end();
  }

  private flushLeftover(message: string): void {
    if (this.git?.hasChanges()) {
      this.dirty = true;
      this.flush(message);
    }
  }

  /** A watcher scan imported sessions into the store — mark dirty and schedule a commit. */
  private onWatcherImported(r: ScanResult): void {
    const span = startSpan('cs.watch');
    this.dirty = true;
    this.pendingTurns += r.turns;
    this.stats.turns += r.turns;
    this.scheduleFlush();
    span.end({ imported: r.imported, turns: r.turns, skipped: r.skipped });
  }

  /**
   * An agent's OTLP export named a session — capture it from the transcript (Claude)
   * or via the source watcher (codex/grok), then debounce a labels+export pass so a
   * burst of metric exports yields one GenAI-semconv emission per quiet period.
   */
  async handleTrigger(sessionId: string): Promise<void> {
    const transcript = findTranscript(this.cfg.claudeProjectsDir, sessionId);
    if (transcript) {
      const res = this.capture.captureSession(sessionId, transcript);
      this.sessions.add(sessionId);
      if (res.newTurns > 0 || res.writtenPaths.length > 0) {
        this.dirty = true;
        this.pendingTurns += res.newTurns;
        this.stats.turns += res.newTurns;
      }
      this.debounceSessionEnd(sessionId, res.sessionDir);
    } else if (this.watcher) {
      this.onWatcherImported(this.watcher.scanOnce());
    }
    this.scheduleFlush();
  }

  /** Coalesce trigger bursts: run onSessionEnd (labels + export) once after a quiet gap. */
  private debounceSessionEnd(sessionId: string, sessionDir: string): void {
    if (!this.onSessionEnd) return;
    const prev = this.triggerTimers.get(sessionId);
    if (prev) clearTimeout(prev);
    const timer = setTimeout(async () => {
      this.triggerTimers.delete(sessionId);
      try {
        await this.onSessionEnd!(sessionId, sessionDir);
        this.dirty = true;
        this.flush(`otel-trigger ${sessionId}`);
      } catch {
        /* labeler/exporter already resilient */
      }
    }, 1500);
    timer.unref?.();
    this.triggerTimers.set(sessionId, timer);
  }

  private rpcCtx(sock?: Socket): RpcContext {
    return {
      cfg: this.cfg,
      sessions: this.sessionService,
      lag: () => ({
        p50: this.lagHist.percentile(50) / 1e6,
        p99: this.lagHist.percentile(99) / 1e6,
      }),
      queueDepth: () => this.pendingTurns,
      daemonVersion: this.daemonVersion,
      tasks: this.tasks,
      subscribe: sock
        ? (filter) => {
            this.subscribers.set(sock, filter);
          }
        : undefined,
    };
  }

  private onConnection(sock: Socket): void {
    let buf = '';
    sock.on('close', () => this.subscribers.delete(sock));
    sock.on('end', () => this.subscribers.delete(sock));
    sock.on('data', async (chunk) => {
      buf += chunk.toString('utf8');
      let nl: number;
      while ((nl = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, nl);
        buf = buf.slice(nl + 1);
        if (!line.trim()) continue;
        const kind = parseLine(line);
        if (kind !== 'hook' && kind !== 'invalid') {
          const rpcSpan = startSpan(`cs.rpc.${kind.method}`);
          try {
            const res = await handleRpc(this.rpcCtx(sock), kind);
            rpcSpan.end({ ok: !res?.error });
            if (res && !sock.destroyed) sock.write(`${JSON.stringify(res)}\n`);
          } catch (e) {
            rpcSpan.end({ err: true });
            throw e;
          }
          continue;
        }
        // Hook path: ack IMMEDIATELY, then process on a serial background queue.
        let evt: HookEvent | null = null;
        try {
          evt = parseHookEvent(JSON.parse(line));
        } catch {
          /* malformed line */
        }
        const ack: HookAck = evt ? { ok: true } : { ok: false, error: 'invalid event' };
        if (!sock.destroyed) sock.write(`${JSON.stringify(ack)}\n`);
        if (evt) this.workQueue = this.workQueue.then(() => this.handleEvent(evt!)).catch(() => {});
      }
    });
    sock.on('error', () => {
      /* client hangup — ignore */
    });
  }

  /** Process a single hook event: capture, then decide whether to flush a commit. */
  async handleEvent(evt: HookEvent): Promise<HookAck> {
    const span = startSpan('cs.hook');
    this.stats.events++;
    // Real-time OTel log emission, fire-and-forget BEFORE the (slower) file capture,
    // so the signal lands even for tool-use events that carry no new transcript turns.
    if (this.onHookEvent) void this.onHookEvent(evt);
    const transcript =
      evt.transcript_path && existsSync(evt.transcript_path)
        ? evt.transcript_path
        : findTranscript(this.cfg.claudeProjectsDir, evt.session_id);
    if (!transcript) {
      span.end({ ok: false, reason: 'transcript not found' });
      return { ok: false, error: 'transcript not found' };
    }

    const res = this.capture.captureSession(evt.session_id, transcript);
    span.mark('capture');
    this.sessions.add(evt.session_id);
    if (res.newTurns > 0 || res.writtenPaths.length > 0) {
      this.dirty = true;
      this.pendingTurns += res.newTurns;
      this.stats.turns += res.newTurns;
    }

    const end = isSessionEndEvent(evt.event);
    let flushed = false;
    if (end && this.onSessionEnd) {
      await this.onSessionEnd(evt.session_id, res.sessionDir);
      this.dirty = true; // insights wrote derived artifacts
    }
    if (end || this.pendingTurns >= this.cfg.batch.maxTurns) {
      flushed = this.flush(`capture ${evt.session_id}`);
    } else {
      this.scheduleFlush();
    }
    span.end({ event: evt.event, session: evt.session_id, newTurns: res.newTurns, flushed });
    return { ok: true, newTurns: res.newTurns, flushed };
  }

  private scheduleFlush(): void {
    if (this.commitTimer) return;
    this.commitTimer = setTimeout(() => {
      this.commitTimer = undefined;
      this.flush('batch interval');
    }, this.cfg.batch.maxIntervalMs);
    this.commitTimer.unref?.();
  }

  /** Commit (and push when configured) all buffered store changes. Returns whether a commit landed. */
  flush(message: string): boolean {
    const span = startSpan('cs.flush');
    if (this.commitTimer) {
      clearTimeout(this.commitTimer);
      this.commitTimer = undefined;
    }
    if (this.git?.hasChanges()) this.dirty = true;
    if (!this.dirty || !this.git) {
      this.dirty = false;
      this.pendingTurns = 0;
      span.end({ skipped: true, message });
      return false;
    }
    const t0 = Date.now();
    const r = this.git.sync(message);
    this.dirty = false;
    this.pendingTurns = 0;
    if (r.commit.committed) this.stats.commits++;
    if (r.commit.committed) {
      this.tasks.record('store.flush', { detail: message, tookMs: Date.now() - t0 });
    }
    span.end({ committed: r.commit.committed, message });
    return r.commit.committed;
  }

  status(): DaemonStatus {
    return {
      running: this.running,
      socketPath: this.cfg.socketPath,
      storeDir: this.cfg.storeDir,
      events: this.stats.events,
      turns: this.stats.turns,
      commits: this.stats.commits,
      sessions: [...this.sessions],
    };
  }

  async stop(): Promise<void> {
    this.watcher?.stop();
    await this.receiver?.stop();
    this.receiver = undefined;
    for (const t of this.triggerTimers.values()) clearTimeout(t);
    this.triggerTimers.clear();
    if (this.commitTimer) {
      clearTimeout(this.commitTimer);
      this.commitTimer = undefined;
    }
    if (this.hygieneTimer) {
      clearInterval(this.hygieneTimer);
      this.hygieneTimer = undefined;
    }
    if (this.hygieneKick) {
      clearTimeout(this.hygieneKick);
      this.hygieneKick = undefined;
    }
    await this.workQueue; // drain any queued hook processing before the final flush
    this.flush('daemon shutdown');
    if (this.server) {
      await new Promise<void>((resolve) => this.server!.close(() => resolve()));
      this.server = undefined;
    }
    if (existsSync(this.cfg.socketPath)) {
      try {
        rmSync(this.cfg.socketPath);
      } catch {
        /* ignore */
      }
    }
    this.subscribers.clear();
    this.lagHist.disable();
    this.running = false;
  }
}
